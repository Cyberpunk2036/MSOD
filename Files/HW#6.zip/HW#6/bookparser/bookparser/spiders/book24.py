# Разберись с переносом обраб. и заесением д-х в б.д.

import scrapy
from scrapy.http import HtmlResponse
from bookparser.items import BookparserItem

import re
import math

class Book24Spider(scrapy.Spider):
    name = 'book24'
    allowed_domains = ['book24.ru']
    start_urls = ['https://book24.ru/search/?q=философия']

    def parse(self, response):
        # Ищем общее количество книг
        count_books = int(response.xpath("//div[@class='search-page__desc']/text()[2]").extract_first().split('\n')[2].replace(' ', ''))
        # Извлекаем ссылки на книги
        links = response.xpath("//div[@class='product-list__item']/article/div[1]/a[1]/@href").extract()
        # Исключение для первой страницы
        try:
            num = int(re.search(r'page-[0-9]+', response.url).group().split('-')[1])
        except AttributeError:
            num = 1
        # Адрес для следующей страницы
        next_page = "https://book24.ru/search/page-" + str(num+1) + "/?q=философия"
        # Условие выхода из цикла скраппинга страниц
        if num != math.ceil(count_books/30):    # 30 - количество книг на странице
            yield response.follow(next_page, callback=self.parse)

        for link in links:  # Для каждой ссылки на книгу
            yield response.follow(link, callback=self.vacancy_parse)    # Передаем ссылку в извлекатель


    def vacancy_parse(self, response):
        name = response.xpath("//h1[@itemprop]/text()").extract_first()
        authors = response.xpath("//div[@class='product-characteristic__value'][1]/a/text()").extract_first()
        first_price = response.xpath("//span[@class='app-price product-sidebar-price__price-old']/text()[1]").extract_first()
        price_discount = response.xpath("//span[@class='app-price product-sidebar-price__price']/text()[1]").extract_first()
        rating = response.xpath("//span[@class='rating-widget__main-text']/text()").extract_first()
        yield BookparserItem(name=name, authors=authors, first_price=first_price, price_discount=price_discount, rating=rating)
        print()
