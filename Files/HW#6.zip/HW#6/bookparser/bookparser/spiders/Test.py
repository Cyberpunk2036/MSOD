# Выводим содержимое документов и их количество
from pymongo import MongoClient

client = MongoClient('localhost', 27017)

db = client.book24shop

for i in db.book24.find({}):
    print(i)

print(db.book24.count_documents({}))
# db.book24.drop({})