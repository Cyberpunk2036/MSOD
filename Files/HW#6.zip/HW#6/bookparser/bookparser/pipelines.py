# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient

import re

class BookparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.data_base = client.book24shop

    def process_item(self, item, spider):
        # Производим обработку данных
        item['name'] = self.processor(string=item['name'])
        item['authors'] = self.processor(string=item['authors'])
        item['first_price'] = self.processor(price=item['first_price'])
        item['price_discount'] = self.processor(price=item['price_discount'])
        item['rating'] = self.processor(rating=item['rating'])

        # Заносим данные в б.д.
        collection = self.data_base[spider.name]
        collection.insert_one(item)
        return item

    def processor(self, string=None, price=None, rating=None):
        """Обрабатываем входные данные"""
        if string is not None:
            # Меняем название или автора книги
            proc_str = re.sub('\s+', ' ', string.split('\n')[1])[1:]
            return proc_str
        if price is not None:
            # Меняем ценовую категорию
            proc_price = int(re.sub('[\D]', '', price))
            return proc_price
        try:
            # Проверяем наличие рейтинга
            proc_rating = float(rating.replace('\n', '').replace(' ', '').replace(',', '.'))
            return proc_rating
        except AttributeError:
            return rating