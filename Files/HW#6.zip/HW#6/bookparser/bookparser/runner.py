from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings

from bookparser import settings  # Подключаем наши настройки
from bookparser.spiders.book24 import Book24Spider    # Подключаем паука

if __name__ == '__main__':

    crawler_settings = Settings()
    crawler_settings.setmodule(settings)    # Устанавливаем наши настройки

    process = CrawlerProcess(settings=crawler_settings)     # Запускаем процесс, то есть паука
    process.crawl(Book24Spider)   # Передаем процессу нашего паука

    process.start()     # Начали!

